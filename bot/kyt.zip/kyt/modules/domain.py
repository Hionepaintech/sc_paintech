from kyt import *

CF_ID = 'mrbaru34@gmail.com'
CF_KEY = 'ebb101a0124686988b8a04be963c66ea6001e'

# Fungsi untuk mendapatkan zone ID
def get_zone_id(domain):
    url = f"https://api.cloudflare.com/client/v4/zones?name={domain}&status=active"
    headers = {
        "X-Auth-Email": CF_ID,
        "X-Auth-Key": CF_KEY,
        "Content-Type": "application/json"
    }
    response = requests.get(url, headers=headers)
    return response.json()['result'][0]['id']

# Fungsi untuk menambahkan atau memperbarui DNS record
def update_dns(domain, subdomain, ip):
    zone_id = get_zone_id(domain)
    dns = f"{subdomain}.{domain}"
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    headers = {
        "X-Auth-Email": CF_ID,
        "X-Auth-Key": CF_KEY,
        "Content-Type": "application/json"
    }
    data = {
        "type": "A",
        "name": dns,
        "content": ip,
        "ttl": 120,
        "proxied": False
    }
    
    # Check if record exists
    existing_record = requests.get(f"{url}?name={dns}", headers=headers).json()
    if existing_record['result']:
        record_id = existing_record['result'][0]['id']
        response = requests.put(f"{url}/{record_id}", headers=headers, json=data)
    else:
        response = requests.post(url, headers=headers, json=data)
    
    return response.json()

@bot.on(events.CallbackQuery(data=b'domain'))
async def point_domain(event):
    async def point_domain_(event):
        async with bot.conversation(chat) as conv:
            await event.respond("Pilih domain:\n1. paintech.shop\n2. vip-server.cloud\n3. isppaintechidn.cloud")
            response = (await conv.get_response()).raw_text
            domain_option = response.strip()

            domains = {
                '1': 'paintech.shop',
                '2': 'vip-server.cloud',
                '3': 'isppaintechidn.cloud'
            }
            
            domain = domains.get(domain_option)

            if not domain:
                await event.respond("Pilihan tidak valid. Keluar.")
                return

            await event.respond("Masukkan nama sub nya:")
            subdomain = (await conv.get_response()).raw_text

            await event.respond("Masukkan IP Address:")
            ip = (await conv.get_response()).raw_text

            result = update_dns(domain, subdomain, ip)
            
            if result['success']:
                msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⟨ SUCCESS ADD IP ADDRESS ⟩**
**━━━━━━━━━━━━━━━━━━━**
`Host :` `{subdomain}.{domain}`
`IP Address :` `{ip}`
**━━━━━━━━━━━━━━━━━━━**
**𝑻𝒉𝒂𝒏𝒌𝒔 𝑭𝒐𝒓 𝑼𝒔𝒆 𝑻𝒉𝒊𝒔 𝑩𝒐𝒕...**
**» 👾@paintechvpn**
"""
                await event.respond(msg, buttons=[Button.inline("Back to menu", b'menu')])
            else:
                await event.respond("Terjadi kesalahan. Silakan coba lagi.")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await point_domain_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
        